# Heimdal On-Prem Müşteri Kurulum Rehberi

Bu rehber, [`values-customer.yaml`](values-customer.yaml) dosyasında referans verilen
registry credential'larının, Kubernetes Secret'larının, TLS kaynaklarının ve Helm
release'inin hangi sırayla hazırlanacağını açıklar.

Secret değerlerini `values-customer.yaml`, Git, TFS, Helm command line veya ticket
içine yazmayın. Production ortamında Vault, External Secrets Operator veya kurumun
secret yöneticisi tercih edilmelidir. Aşağıdaki `kubectl` komutları manuel kurulum
ve PoC için örnektir.

## 1. Gereksinimleri kontrol edin

Gerekli bileşenler:

- Kubernetes cluster ve `kubectl` erişimi
- Helm 3
- Kalıcı disk oluşturabilen bir StorageClass (PostgreSQL ve Redis chart ile kurulur)
- Heimdal Runtime ve LiteLLM Gateway image'larının bulunduğu registry
- LLM Firewall endpoint'i
- Ingress Controller veya müşterinin mevcut Gateway/Ingress çözümü
- LDAP/LDAPS kullanılacaksa LDAP bağlantı bilgileri

```bash
kubectl version --client
helm version
kubectl cluster-info
```

## 2. Namespace oluşturun

```bash
kubectl create namespace heimdal
```

Namespace zaten varsa komut hata verebilir; mevcut namespace silinmemelidir.

## 3. Private registry erişimini oluşturun

GHCR, Harbor, Artifactory veya başka bir private registry kullanılıyorsa:

```bash
kubectl create secret docker-registry heimdal-registry \
  --namespace heimdal \
  --docker-server=CHANGE_ME_REGISTRY_HOST \
  --docker-username=CHANGE_ME_REGISTRY_USERNAME \
  --docker-password=CHANGE_ME_REGISTRY_TOKEN
```

Private registry doğrulaması:

```bash
kubectl get secret heimdal-registry -n heimdal
```

## 4. PostgreSQL ve Redis depolamasını seçin

Varsayılan `postgresql.mode: managed` ve `redis.mode: managed` ile chart iki ayrı
StatefulSet, Service, PVC ve parola Secret'ı oluşturur. Müşterinin PostgreSQL veya
Redis kurmasına gerek yoktur. PostgreSQL içinde `litellm` ve `heimdal` veritabanları
ayrı, superuser olmayan kullanıcılarla oluşturulur. İki servis de tek replica'dır.

Varsayılan diskler PostgreSQL için 20Gi, Redis için 8Gi'dir. `managed.persistence`
altından `storageClass`, `size` veya `existingClaim` ayarlanabilir. Kalıcılığı
kapatmak yalnız geçici test ortamları içindir.

Harici PostgreSQL kullanılacaksa `postgresql.mode: external` seçilir ve aşağıdaki
Secret'lara `DATABASE_URL` / `database-url` eklenir. Harici bağlantıda TLS kullanın.
Mevcut harici veritabanından managed moda geçiş veri taşımaz; ayrıca yedekleme ve
geri yükleme gerekir. Mevcut harici kurulumlarda upgrade öncesi modu açıkça external
yapın. Ayrıntılar: [Managed veri servisleri](../../../docs/operations/managed-data-services.md).

## 5. LiteLLM temel Secret'ını oluşturun

Önce güçlü anahtarlar üretin:

```bash
openssl rand -hex 32
openssl rand -hex 32
```

İlk değer `LITELLM_MASTER_KEY`, ikinci değer `LITELLM_SALT_KEY` olarak kullanılır.
Master key `sk-` prefix'iyle verilmelidir. Salt key ilk kurulumdan sonra
değiştirilmemeli ve PostgreSQL backup'ıyla birlikte güvenli biçimde yedeklenmelidir.

### Managed Redis kullanılıyorsa

```bash
kubectl create secret generic heimdal-litellm-env \
  --namespace heimdal \
  --from-literal=LITELLM_MASTER_KEY='sk-CHANGE_ME_RANDOM_MASTER_KEY' \
  --from-literal=LITELLM_SALT_KEY='CHANGE_ME_RANDOM_SALT_KEY'
```

### External Redis kullanılıyorsa

```bash
kubectl create secret generic heimdal-litellm-env \
  --namespace heimdal \
  --from-literal=LITELLM_MASTER_KEY='sk-CHANGE_ME_RANDOM_MASTER_KEY' \
  --from-literal=LITELLM_SALT_KEY='CHANGE_ME_RANDOM_SALT_KEY' \
  --from-literal=REDIS_HOST='CHANGE_ME_REDIS_HOST' \
  --from-literal=REDIS_PORT='6379' \
  --from-literal=REDIS_PASSWORD='CHANGE_ME_REDIS_PASSWORD' \
  --from-literal=REDIS_SSL='True'
```

`REDIS_USERNAME` yalnız Redis ACL kullanılıyorsa eklenir. Model/provider API key'i
bu Secret'a eklenmez; model kurulumdan sonra LiteLLM Admin UI'dan tanımlanır.

### Opsiyonel PostgreSQL read replica (external mod)

LiteLLM'in desteklediği okuma yollarını writer'dan ayırmak için
`DATABASE_URL_READ_REPLICA` aynı Secret'a eklenebilir:

```bash
kubectl create secret generic heimdal-litellm-env \
  --namespace heimdal \
  --from-literal=LITELLM_MASTER_KEY='sk-CHANGE_ME_RANDOM_MASTER_KEY' \
  --from-literal=LITELLM_SALT_KEY='CHANGE_ME_RANDOM_SALT_KEY' \
  --from-literal=DATABASE_URL='postgresql://CHANGE_ME_USER:CHANGE_ME_PASSWORD@CHANGE_ME_WRITER_HOST:5432/litellm?sslmode=require' \
  --from-literal=DATABASE_URL_READ_REPLICA='postgresql://CHANGE_ME_USER:CHANGE_ME_PASSWORD@CHANGE_ME_READER_HOST:5432/litellm?sslmode=require'
```

Customer values:

```yaml
gateway:
  postgresql:
    readReplica:
      enabled: true
      secretName: heimdal-litellm-env
      secretKey: DATABASE_URL_READ_REPLICA
```

Reader endpoint müşterinin PostgreSQL HA katmanı tarafından sağlanır. Chart replica
oluşturmaz ve replication lag/failover yönetmez.

### Opsiyonel external PgBouncer (postgresql.mode=external)

Chart PgBouncer kurmaz. External PgBouncer servisi varsa `DATABASE_URL`, doğrudan
PostgreSQL yerine PgBouncer writer endpoint'ini göstermelidir:

```text
postgresql://USER:PASSWORD@PGBOUNCER_HOST:6432/litellm?sslmode=require
```

Transaction pooling kullanıldığında:

```yaml
gateway:
  postgresql:
    pooler:
      enabled: true
      mode: transaction
      disablePreparedStatements: true
```

`disablePreparedStatements: true` unutulursa Helm kurulumu bilinçli olarak hata
verir. Session pooling kullanılıyorsa kurumun PgBouncer kapasite ve bağlantı
politikası ayrıca doğrulanmalıdır.

## 6. Heimdal Control Plane Secret'ını oluşturun

```bash
kubectl create secret generic heimdal-control-plane \
  --namespace heimdal \
  --from-literal=admin-api-key="$(openssl rand -hex 32)"
```

External PostgreSQL kullanılıyorsa bu Secret'a `database-url`, LiteLLM ortam
Secret'ına `DATABASE_URL` ekleyin. Managed modda bu alanlar gerekli değildir.

## 7. Redis modunu hazırlayın

### Seçenek A — Managed Redis

Customer values:

```yaml
redis:
  mode: managed
```

Parola Secret'ı otomatik oluşturulur; manuel işlem gerekmez. Mevcut bir parola
Secret'ı kullanılacaksa `redis.managed.auth.existingSecret` belirtilebilir.

Yeni PVC oluşturulacaksa StorageClass girin:

```yaml
redis:
  managed:
    persistence:
      existingClaim: ""
      storageClass: "CHANGE_ME_RWO_STORAGE_CLASS"
      size: 8Gi
```

Mevcut RWO PVC kullanılacaksa:

```yaml
redis:
  managed:
    persistence:
      existingClaim: "customer-redis-pvc"
```

Managed Redis tek replica çalışır ve HA sağlamaz.

### Seçenek B — External Redis

Customer values:

```yaml
redis:
  mode: external
```

`heimdal-litellm-env` Secret'ına Redis bağlantı alanları 5. adımdaki gibi eklenir.
Runtime için iki URL Secret'ı oluşturulur:

```bash
kubectl create secret generic heimdal-policy-cache \
  --namespace heimdal \
  --from-literal=redis-url='rediss://CHANGE_ME_USER:CHANGE_ME_PASSWORD@CHANGE_ME_REDIS_HOST:6379/1'
```

Audit Secret'ı sonraki adımda `/2` bağlantısını da alacaktır.

## 8. Audit Secret'ını oluşturun

### Managed Redis

```bash
kubectl create secret generic heimdal-audit \
  --namespace heimdal \
  --from-literal=hash-key="$(openssl rand -hex 32)"
```

### External Redis

```bash
kubectl create secret generic heimdal-audit \
  --namespace heimdal \
  --from-literal=hash-key="$(openssl rand -hex 32)" \
  --from-literal=redis-url='rediss://CHANGE_ME_USER:CHANGE_ME_PASSWORD@CHANGE_ME_REDIS_HOST:6379/2'
```

## 9. LLM Firewall Secret'ını oluşturun

Firewall ekibinden alınan API key ve ayrı üretilmiş session HMAC key kullanılır:

```bash
kubectl create secret generic heimdal-llm-firewall \
  --namespace heimdal \
  --from-literal=api-key='CHANGE_ME_FIREWALL_API_KEY' \
  --from-literal=session-hmac-key="$(openssl rand -hex 32)"
```

Customer values içindeki endpoint'i güncelleyin:

```yaml
runtime:
  llmFirewall:
    url: "http://CHANGE_ME_FIREWALL_SERVICE:5032"
```

## 10. LDAP/LDAPS ve OIDC Secret'ını oluşturun

Identity kullanılmayacaksa bu adımı atlayın ve `identity.enabled: false` bırakın.

LDAP/LDAPS kullanılacaksa:

```bash
kubectl create secret generic heimdal-identity \
  --namespace heimdal \
  --from-literal=HEIMDAL_SESSION_SECRET="$(openssl rand -hex 32)" \
  --from-literal=HEIMDAL_OIDC_CLIENT_SECRET="$(openssl rand -hex 32)" \
  --from-literal=HEIMDAL_LDAP_URL='ldaps://CHANGE_ME_LDAP_HOST:636' \
  --from-literal=HEIMDAL_LDAP_BASE_DN='DC=example,DC=internal' \
  --from-literal=HEIMDAL_LDAP_BIND_DN='CN=heimdal-reader,OU=Service Accounts,DC=example,DC=internal' \
  --from-literal=HEIMDAL_LDAP_BIND_PASSWORD='CHANGE_ME_LDAP_BIND_PASSWORD' \
  --from-literal=HEIMDAL_LDAP_USER_FILTER='(sAMAccountName={username})' \
  --from-literal=HEIMDAL_LDAP_ID_ATTRIBUTE='objectGUID' \
  --from-literal=HEIMDAL_LDAP_EMAIL_ATTRIBUTE='mail' \
  --from-literal=HEIMDAL_LDAP_NAME_ATTRIBUTE='displayName' \
  --from-literal=HEIMDAL_LDAP_GROUP_ATTRIBUTE='memberOf'
```

Ardından customer values:

```yaml
identity:
  enabled: true
  issuer: "https://heimdal-auth.customer.internal"
  litellmUiUrl: "https://heimdal.customer.internal"
  oidc:
    redirectUris: "https://heimdal.customer.internal/sso/callback"
```

`ldap://...:389` kullanıldığında Heimdal bind öncesinde StartTLS uygular;
`ldaps://...:636` doğrudan TLS kullanır. Düz metin LDAP bind desteklenmez.

LDAP sunucusu kurumsal private CA kullanıyorsa CA bundle Secret'ını oluşturun:

```bash
kubectl create secret generic heimdal-ldap-ca \
  --namespace heimdal \
  --from-file=ca.crt=/secure/path/corporate-ldap-ca.crt
```

Customer values içinde mount'u etkinleştirin:

```yaml
identity:
  ldap:
    caCert:
      existingSecret: heimdal-ldap-ca
      key: ca.crt
```

Public CA kullanılıyorsa `existingSecret: ""` bırakılır. TLS sertifika doğrulaması
kapatılmamalıdır.

## 11. Opsiyonel break-glass yerel admin

Yalnız acil durum hesabı gerekiyorsa identity Secret'ına şu key'leri ekleyin:

```text
HEIMDAL_LOCAL_ADMIN_USERNAME
HEIMDAL_LOCAL_ADMIN_PASSWORD
```

Ve customer values:

```yaml
identity:
  localAdmin:
    enabled: true
```

Günlük kullanım için LDAP hesapları kullanılmalıdır.

## 12. TLS Secret'larını oluşturun

Cert-manager kullanılmıyorsa gateway TLS Secret'ı:

```bash
kubectl create secret tls heimdal-gateway-tls \
  --namespace heimdal \
  --cert=/secure/path/gateway-tls.crt \
  --key=/secure/path/gateway-tls.key
```

Ayrı identity hostname'i yayınlanıyorsa:

```bash
kubectl create secret tls heimdal-identity-tls \
  --namespace heimdal \
  --cert=/secure/path/identity-tls.crt \
  --key=/secure/path/identity-tls.key
```

Cert-manager kullanılıyorsa ilgili Ingress annotation'ı açılır; cert-manager aynı
Secret adlarıyla sertifikaları üretir. Müşterinin mevcut Ingress'i TLS'i kendisi
sonlandırıyorsa chart ingress'i kapatılabilir.

## 13. Customer values dosyasını tamamlayın

Kalan placeholder'ları bulun:

```bash
grep -n 'CHANGE_ME' values-customer.yaml
```

Yalnız etkinleştirilen bölümlerdeki placeholder'ların tamamı değiştirilmelidir.

Başlıca alanlar:

- Registry repository adresleri
- Redis modu, StorageClass veya existing PVC
- Firewall Service URL
- Gateway DNS hostname'i
- Identity etkinse auth hostname ve callback URL
- Ingress class ve TLS Secret adları

## 14. Secret referanslarını doğrulayın

```bash
kubectl get secrets -n heimdal
```

Managed Redis için beklenen temel liste:

```text
heimdal-registry
heimdal-litellm-env
heimdal-control-plane
heimdal-audit
heimdal-llm-firewall
```

Identity/TLS durumuna göre `heimdal-identity`, `heimdal-gateway-tls` ve
`heimdal-identity-tls` eklenir. External Redis'te
`heimdal-policy-cache` ve external Redis key'leri bulunur.

## 15. Helm doğrulaması yapın

```bash
cd deploy/helm/heimdal
helm lint . -f values-customer.yaml
helm template heimdal . \
  --namespace heimdal \
  -f values-customer.yaml > rendered.yaml
```

Managed modda render çıktısı üretilen Secret değerlerini içerir; Git'e eklemeyin.
Offline `helm template` lookup yapamaz ve her render'da yeni parola üretir.
Kurulum/güncelleme için doğrudan `helm upgrade --install` kullanın; GitOps için
`managed.auth.existingSecret` ile önceden yönetilen Secret'lara referans verin.

## 16. Kurulumu başlatın

```bash
helm upgrade --install heimdal . \
  --namespace heimdal \
  --create-namespace \
  -f values-customer.yaml \
  --atomic \
  --wait \
  --timeout 15m
```

## 17. Kurulumu doğrulayın

```bash
kubectl get pods,svc,ingress,pvc -n heimdal
kubectl get jobs -n heimdal
kubectl rollout status deployment/heimdal-runtime -n heimdal
kubectl rollout status deployment/heimdal-gateway -n heimdal
```

Managed servisler için:

```bash
kubectl rollout status statefulset/heimdal-postgresql -n heimdal
kubectl rollout status statefulset/heimdal-redis -n heimdal
```

Hazırlık kontrolü:

```bash
kubectl port-forward service/heimdal-runtime 8080:8080 -n heimdal
curl -fsS http://127.0.0.1:8080/health/ready
```

Kurulum tamamlandıktan sonra LiteLLM Admin UI açılır ve kullanılacak model/provider
credential'ları UI üzerinden tanımlanır.

## Secret güncelleme

Environment Secret'ı değiştirildiğinde pod içindeki değer otomatik değişmez.
Stakater Reloader kullanılmıyorsa `gateway.secretRevision` artırılarak Helm upgrade
çalıştırılmalı veya kontrollü rollout yapılmalıdır.

```bash
kubectl rollout restart deployment/heimdal-runtime -n heimdal
kubectl rollout restart deployment/heimdal-gateway -n heimdal
```

`LITELLM_SALT_KEY` normal secret rotation kapsamında değiştirilmemelidir.
