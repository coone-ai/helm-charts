# OpenShift / Kubernetes Hızlı Kurulum, Secret & Kimlik Doğrulama Rehberi

Bu rehber, **OpenShift (CRC / OCP)** veya standart **Kubernetes** ortamında **Heimdal (LiteLLM Gateway & Runtime Control Plane)** kurulumu öncesinde gerekli Secret'ların oluşturulması, Helm ile servisin ayağa kaldırılması ve **Local Admin / LDAP Kimlik Doğrulama** adımlarını özetler.

---

## 1. Proje (Namespace) Oluşturma

```bash
# OpenShift için:
oc new-project heimdal 2>/dev/null || oc project heimdal

# Standart Kubernetes için:
# kubectl create namespace heimdal 2>/dev/null || kubectl config set-context --current --namespace=heimdal
```

---

## 2. Temel Secret'ların Oluşturulması

### A) Container Registry İmaj Çekme Secret'ı (`heimdal-registry`)

```bash
# GHCR veya Özel Container Registry pull secret'ı:
oc create secret docker-registry heimdal-registry \
  --docker-server=ghcr.io \
  --docker-username="<GITHUB_KULLANICI_ADI_VEYA_ORG>" \
  --docker-password="<GITHUB_PAT_TOKEN_READ_PACKAGES>" \
  -n heimdal
```

### B) Managed Redis Şifre Secret'ı (`heimdal-managed-redis`)

```bash
# Managed Redis için güçlü rastgele şifre üretip secret oluşturur:
oc create secret generic heimdal-managed-redis \
  --from-literal=password="$(openssl rand -hex 32)" \
  -n heimdal
```

### C) Heimdal Control Plane Secret'ı (`heimdal-control-plane`)

```bash
# PostgreSQL DB URL'i ve Heimdal Admin API anahtarı:
POSTGRES_PASSWORD="<POSTGRES_SIFRENIZ>"
POSTGRES_HOST="<POSTGRES_HOST_VEYA_SERVIS_ADI>"

oc create secret generic heimdal-control-plane \
  --from-literal=database-url="postgresql://litellm:${POSTGRES_PASSWORD}@${POSTGRES_HOST}:5432/litellm" \
  --from-literal=admin-api-key="sk-heimdal-admin-$(openssl rand -hex 16)" \
  -n heimdal
```

### D) Audit Hash Key Secret'ı (`heimdal-audit`)

```bash
# Denetim logları bütünlüğü için 32-byte HMAC anahtarı:
oc create secret generic heimdal-audit \
  --from-literal=hash-key="$(openssl rand -hex 32)" \
  -n heimdal
```

### E) LLM Firewall Bağlantı Secret'ı (`heimdal-llm-firewall`)

```bash
# DLP / LLM Firewall servisi ile haberleşme anahtarları:
oc create secret generic heimdal-llm-firewall \
  --from-literal=api-key="<DLP_FIREWALL_API_KEY>" \
  --from-literal=session-hmac-key="$(openssl rand -hex 32)" \
  -n heimdal
```

### F) LiteLLM Gateway Ortam Secret'ı (`heimdal-litellm-env`)

```bash
# LiteLLM Master Key, Salt Key ve Veritabanı bağlantısı:
oc create secret generic heimdal-litellm-env \
  --from-literal=LITELLM_MASTER_KEY="sk-heimdal-$(openssl rand -hex 16)" \
  --from-literal=LITELLM_SALT_KEY="sk-salt-$(openssl rand -hex 16)" \
  --from-literal=DATABASE_URL="postgresql://litellm:${POSTGRES_PASSWORD}@${POSTGRES_HOST}:5432/litellm" \
  -n heimdal
```

---

## 3. Web Arayüzü & Kimlik Doğrulama Seçenekleri (Identity)

Heimdal Admin Paneli (`/admin`) için 3 farklı giriş yöntemi mevcuttur:

### Seçenek 1: LiteLLM UI (Doğrudan Master Key ile Giriş — LDAP Gerekmez)
LiteLLM yönetim paneline (`http://localhost:4000/ui`) giriş için kimlik servisine veya LDAP'a ihtiyaç yoktur. Doğrudan `LITELLM_MASTER_KEY` ile giriş yapılır.

---

### Seçenek 2: Local Admin (Yerel Kullanıcı Adı & Şifre ile Giriş — LDAP Gerekmez)
LDAP sunucunuz yoksa veya acil durum break-glass hesabı ile Heimdal Admin paneline (`http://localhost:8080/admin`) kullanıcı adı ve şifreyle girmek için:

#### 1. `heimdal-identity` Secret'ını oluşturun:
```bash
oc create secret generic heimdal-identity \
  --from-literal=HEIMDAL_SESSION_SECRET="$(openssl rand -hex 32)" \
  --from-literal=HEIMDAL_LOCAL_ADMIN_ENABLED="true" \
  --from-literal=HEIMDAL_LOCAL_ADMIN_USERNAME="admin" \
  --from-literal=HEIMDAL_LOCAL_ADMIN_PASSWORD="<GUCLU_ADMIN_SIFRENIZ>" \
  -n heimdal
```

#### 2. `values-customer.yaml` içinde aktif edin:
```yaml
identity:
  enabled: true
  issuer: "http://localhost:8080"
  litellmUiUrl: "http://localhost:4000"
  existingEnvSecrets:
    - heimdal-identity
  localAdmin:
    enabled: true
```

---

### Seçenek 3: Kurumsal LDAP / Active Directory & SSO Entegrasyonu
Kurumsal kullanıcıların kendi Active Directory / OpenLDAP hesaplarıyla (`Heimdal-Admins`, `Heimdal-Auditors` grupları) giriş yapması için:

#### 1. LDAP Secret'ını (`heimdal-identity`) oluşturun:
```bash
oc create secret generic heimdal-identity \
  --from-literal=HEIMDAL_SESSION_SECRET="$(openssl rand -hex 32)" \
  --from-literal=HEIMDAL_OIDC_CLIENT_SECRET="$(openssl rand -hex 32)" \
  --from-literal=HEIMDAL_LDAP_URL="ldaps://ldap.sirketiniz.internal:636" \
  --from-literal=HEIMDAL_LDAP_BASE_DN="DC=sirketiniz,DC=internal" \
  --from-literal=HEIMDAL_LDAP_BIND_DN="CN=heimdal-reader,OU=ServiceAccounts,DC=sirketiniz,DC=internal" \
  --from-literal=HEIMDAL_LDAP_BIND_PASSWORD="<LDAP_BIND_SIFRENIZ>" \
  --from-literal=HEIMDAL_LDAP_USER_FILTER="(sAMAccountName={username})" \
  --from-literal=HEIMDAL_LDAP_ID_ATTRIBUTE="objectGUID" \
  --from-literal=HEIMDAL_LDAP_EMAIL_ATTRIBUTE="mail" \
  --from-literal=HEIMDAL_LDAP_NAME_ATTRIBUTE="displayName" \
  --from-literal=HEIMDAL_LDAP_GROUP_ATTRIBUTE="memberOf" \
  -n heimdal
```

*(Eğer kurumunuz özel bir Root CA Sertifikası kullanıyorsa `oc create secret generic heimdal-ldap-ca --from-file=ca.crt=/yol/root-ca.crt -n heimdal` oluşturun).*

#### 2. `values-customer.yaml` içinde LDAP'ı aktif edin:
```yaml
identity:
  enabled: true
  issuer: "https://auth.sirketiniz.com"
  litellmUiUrl: "https://gateway.sirketiniz.com"
  existingEnvSecrets:
    - heimdal-identity
  ldap:
    adminGroups: "Heimdal-Admins"
    auditorGroups: "Heimdal-Auditors"
    caCert:
      existingSecret: "" # Özel CA varsa "heimdal-ldap-ca"
      key: ca.crt
  localAdmin:
    enabled: false
  oidc:
    clientId: "litellm-ui"
    redirectUris: "https://gateway.sirketiniz.com/sso/callback"
```

---

## 4. Helm ile Kurulum & Güncelleme

### values-customer.yaml Dosyasını Düzenleme:
`deploy/helm/heimdal/values-customer.yaml` dosyasında imaj ve servis adreslerini teyit edin:
* `runtime.image.repository`: `ghcr.io/coone-ai/heimdal-gateway/runtime`
* `gateway.image.repository`: `ghcr.io/coone-ai/heimdal-gateway/litellm-gateway`
* `runtime.llmFirewall.url`: Cluster içi firewall adresi (`http://dlp-masking-service.dlp-masking.svc:8000`)
* `runtime.llmFirewall.inspectPath`: Firewall inceleme endpoint'i (varsayılan: `/v1/guard/inspect`)
* `runtime.llmFirewall.verifyCapabilities`: Runtime'ın API key ile `GET /healthz` sözleşmesini doğrulamasını kontrol eder; üretimde `true` önerilir.
* Firewall başka cluster'daki özel CA imzalı HTTPS Route ise `runtime.llmFirewall.caCert.existingSecret` ve `key` alanlarını Heimdal namespace'indeki CA Secret'ına bağlayın. Chart CA'yı `/etc/ssl/custom-certs` altına mount ederek Python/Requests/HTTPX doğrulama env'lerini otomatik tanımlar.
* `gateway.ingress.enabled`: `false` *(OpenShift Route kullanılacağı için)*
* `gateway.caCert`: Gateway HTTPS provider'lara kurumsal CA/TLS inspection üzerinden çıkıyorsa kullanılacak birleşik CA bundle Secret'ı. Identity Secret'ına `SSL_CERT_FILE` eklenmemelidir.

### Kurulum Komutu:
```bash
helm upgrade --install heimdal ./deploy/helm/heimdal \
  -n heimdal \
  -f ./deploy/helm/heimdal/values-customer.yaml
```

---

## 5. Dış Dünyaya Açma (OpenShift Route) & Dashboard Erişimi

### A) Servisleri OpenShift Route ile Dışarı Açın:
```bash
oc expose svc/heimdal-gateway -n heimdal
oc expose svc/heimdal-runtime -n heimdal

# Dış erişim adreslerini görün:
oc get routes -n heimdal
```

### B) Kendi Lokal Bilgisayarınızdan Dashboard'lara Bağlanma (SSH Port Forward):
Uzak sunucudaki cluster'a lokal tarayıcınızdan bağlanmak için:

```bash
# 1. Kendi Mac terminalinizde tünel açın:
ssh -L 8080:localhost:8080 -L 4000:localhost:4000 coone@<UZAK_SUNUCU_IP>

# 2. Uzak sunucuda port-forward'ları başlatın:
oc port-forward svc/heimdal-runtime 8080:8080 -n heimdal &
oc port-forward svc/heimdal-gateway 4000:4000 -n heimdal &
```

* **Heimdal Admin Paneli:** [http://localhost:8080/admin](http://localhost:8080/admin)
* **LiteLLM Yönetim Paneli:** [http://localhost:4000/ui](http://localhost:4000/ui) *(Giriş için Master Key kullanılır)*

---

## 6. Kurulum Doğrulama Testi (Örnek cURL)

### Gateway Chat Completion Endpoint Testi:
```bash
LITELLM_KEY=$(oc get secret heimdal-litellm-env -n heimdal -o jsonpath='{.data.LITELLM_MASTER_KEY}' | base64 -d)

curl -X POST "http://localhost:4000/v1/chat/completions" \
  -H "Authorization: Bearer $LITELLM_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "heimdal-local",
    "metadata": {
      "tenant_id": "vodafone",
      "application_id": "default-app"
    },
    "messages": [
      {
        "role": "user",
        "content": "Merhaba, Ahmet Yılmaz telefon numarası: 0532 123 45 67"
      }
    ]
  }'
```

---

## 7. `values-customer.yaml` İçindeki `CHANGE_ME` Alanları Rehberi

`values-customer.yaml` dosyasında ortamınıza göre özelleştirmeniz gereken tüm `CHANGE_ME_*` yer tutucularının açıklamaları ve örnek değerleri aşağıdadır:

| Parametre Alanı | Açıklama & Amaç | Örnek Değer |
|---|---|---|
| **`identity.issuer`** | Heimdal OIDC Kimlik Sağlayıcısının (Auth/Runtime) dış dünyaya açık URL'i. Kullanıcılar oturum açarken bu adrese yönlendirilir. | `https://auth.sirketiniz.com` *(Lokal için: `http://localhost:8080`)* |
| **`identity.litellmUiUrl`** | LiteLLM Web Arayüzünün dış erişim URL'i. Heimdal SSO girişinden sonra kullanıcıyı bu adresteki panele aktarır. | `https://gateway.sirketiniz.com` *(Lokal için: `http://localhost:4000`)* |
| **`identity.oidc.redirectUris`** | OIDC oturum açma akışı tamamlandığında yetki kodunun teslim edileceği LiteLLM SSO callback adresi. Her zaman `litellmUiUrl` + `/sso/callback` olmalıdır. | `https://gateway.sirketiniz.com/sso/callback` *(Lokal için: `http://localhost:4000/sso/callback`)* |
| **`runtime.llmFirewall.url`** | Prompt Injection ve PII tespitini yapan Co-one DLP Masking / LLM Firewall servisinin cluster içi adresi ve portu. | `http://dlp-masking-service.dlp-masking.svc:8000` *(veya `http://dlp-masking-service:8000`)* |
| **`runtime.image.repository`** | Heimdal Runtime & Control Plane container imajının Container Registry yolu. | `ghcr.io/coone-ai/heimdal-gateway/runtime` |
| **`gateway.image.repository`** | Heimdal LiteLLM Gateway container imajının Container Registry yolu. | `ghcr.io/coone-ai/heimdal-gateway/litellm-gateway` |
| **`redis.managed.persistence.storageClass`** | Managed Redis'in verilerini saklayacağı disk tipi (StorageClass). Boş bırakılırsa (`""`) cluster'ın varsayılan disk sınıfı otomatik seçilir. | `""` *(veya `crc-csi-hostpath-provisioner`, `gp3`, `standard`)* |
| **`gateway.ingress.hosts[0].host`** | Kubernetes Ingress Controller kullanılıyorsa Gateway'in dış DNS adı. OpenShift Route kullanılıyorsa `ingress.enabled: false` yapılır. | `gateway.sirketiniz.com` *(veya OpenShift Route ile dinamik)* |
| **`identity.identityIngress.host`** | Ayrı bir Auth Ingress hostname'i yayınlanacaksa tanımlanır. | `auth.sirketiniz.com` |

---

### Hangi Modda Hangileri Zorunludur?

* **Minimal / Standart Kurulum (LDAP Kapalı - `identity.enabled: false`):**
  Yalnızca `runtime.llmFirewall.url`, `runtime.image.repository` ve `gateway.image.repository` değerlerini girmeniz yeterlidir. Diğer kimlik alanları tamamen göz ardı edilir.
* **Local Admin Modu (`identity.enabled: true` & `localAdmin.enabled: true`):**
  `issuer` (`http://localhost:8080`) ve `litellmUiUrl` (`http://localhost:4000`) girilir.
* **Kurumsal SSO Modu (`identity.enabled: true` & LDAP):**
  Yukarıdaki tüm `identity.*` domain alanlarının gerçek kurumsal DNS adreslerinizle doldurulması gerekir.
