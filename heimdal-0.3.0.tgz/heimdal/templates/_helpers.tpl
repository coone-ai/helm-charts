{{- define "heimdal.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "heimdal.image" -}}
{{- $image := .image -}}
{{ printf "%s:%s" $image.repository $image.tag }}
{{- end }}

{{- define "heimdal.fullname" -}}
{{- default (printf "%s-%s" .Release.Name (include "heimdal.name" .)) .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "heimdal.redisServiceName" -}}
{{ printf "%s-redis" (include "heimdal.fullname" .) }}
{{- end }}

{{- define "heimdal.labels" -}}
app.kubernetes.io/name: {{ include "heimdal.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "heimdal.postgresqlServiceName" -}}
{{ printf "%s-postgresql" (include "heimdal.fullname" .) }}
{{- end }}

{{- define "heimdal.postgresqlSecretName" -}}
{{ default (printf "%s-postgresql-auth" (include "heimdal.fullname" .)) .Values.postgresql.managed.auth.existingSecret }}
{{- end }}

{{- define "heimdal.redisSecretName" -}}
{{ default (printf "%s-redis-auth" (include "heimdal.fullname" .)) .Values.redis.managed.auth.existingSecret }}
{{- end }}

{{- define "heimdal.databaseSecretName" -}}
{{- if eq .Values.postgresql.mode "managed" -}}
{{ include "heimdal.postgresqlSecretName" . }}
{{- else -}}
{{ .Values.gateway.postgresql.writer.secretName }}
{{- end -}}
{{- end }}
{{- define "heimdal.databaseSecretKey" -}}
{{- if eq .Values.postgresql.mode "managed" -}}database-url{{- else -}}{{ .Values.gateway.postgresql.writer.secretKey }}{{- end -}}
{{- end }}
{{- define "heimdal.runtimeDatabaseSecretName" -}}
{{- if eq .Values.postgresql.mode "managed" -}}
{{ include "heimdal.postgresqlSecretName" . }}
{{- else -}}
{{ .Values.runtime.controlPlane.databaseSecret.name }}
{{- end -}}
{{- end }}
{{- define "heimdal.runtimeDatabaseSecretKey" -}}
{{- if eq .Values.postgresql.mode "managed" -}}heimdal-database-url{{- else -}}{{ .Values.runtime.controlPlane.databaseSecret.key }}{{- end -}}
{{- end }}

{{/* Managed Jobs run after ordinary resources exist. Pods wait for this
release's successful migration marker, avoiding pre-install hook deadlocks. */}}
{{- define "heimdal.waitDatabase" -}}
- name: {{ ternary "wait-schema" "wait-postgresql" .schema }}
  image: {{ include "heimdal.image" (dict "image" .root.Values.postgresql.managed.image) | quote }}
  imagePullPolicy: {{ .root.Values.postgresql.managed.image.pullPolicy }}
  command: ["sh", "-ec"]
  args:
    - |
      until psql "$DATABASE_URL" -Atqc {{ if .schema }}"SELECT 1 FROM public.heimdal_chart_migrations WHERE revision={{ .root.Release.Revision }}"{{ else }}"SELECT 1"{{ end }} 2>/dev/null | grep -qx 1; do
        echo "Waiting for {{ ternary "schema migration" "PostgreSQL" .schema }}..."
        sleep 3
      done
  env:
    - name: PGCONNECT_TIMEOUT
      value: "5"
    - name: DATABASE_URL
      valueFrom:
        secretKeyRef:
          name: {{ .secretName }}
          key: {{ .secretKey }}
  securityContext:
    {{- with .root.Values.postgresql.managed.podSecurityContext.runAsUser }}
    runAsUser: {{ . }}
    {{- end }}
    allowPrivilegeEscalation: false
    readOnlyRootFilesystem: true
    capabilities:
      drop: ["ALL"]
{{- end }}
