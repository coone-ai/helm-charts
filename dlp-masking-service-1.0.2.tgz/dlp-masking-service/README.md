# DLP Masking Service — OpenShift On-Prem Kurulum Rehberi

Bu chart DLP Masking Service'i müşteri OpenShift/Kubernetes ortamına kurar. Dosya
işleri PostgreSQL checkpoint'leri ve ortak dosya alanındaki atomik Parquet
chunk'larıyla yürütülür. Worker veya pod yeniden başladığında tamamlanmış
chunk'lar korunur; yalnızca yarım kalan chunk yeniden denenir.

## Bileşenler

| Bileşen | Görev |
|---|---|
| `frontend` | Streamlit kullanıcı arayüzü |
| `backend` | FastAPI metin/dosya API'si |
| `worker` | Celery model worker'ı; chunk maskeleme ve finalizasyon |
| `beat` | Worker/chunk lease recovery |
| `postgresql` | Job/chunk checkpoint, attempt ve hata kayıtları |
| `redis` | Celery broker ve geçici task-result backend |
| `jobStorage` | İşlem sırasında geçici ham/chunk dosyaları ve kalıcı maskelenmiş çıktılar için ortak PVC |

PostgreSQL ve Redis chart ile kurulabilir veya kurumun yönettiği harici
servisler kullanılabilir. Dış erişim varsayılan olarak kapalıdır; OpenShift'te
frontend Route, standart Kubernetes'te Ingress açıkça etkinleştirilmelidir.

## API kimlik doğrulama

Chart, ilk kurulumda 48 karakterlik rastgele bir API anahtarı üretir. Backend'in
`/health` dışındaki endpoint'leri `X-API-Key` header'ını zorunlu tutar. Streamlit
frontend aynı Kubernetes Secret'ını server-side okuyarak backend çağrılarına
header'ı otomatik ekler; anahtar tarayıcıya gönderilmez.

Hazır bir Secret kullanmak önerilen üretim yöntemidir:

```yaml
apiAuth:
  apiKey: ""
  existingSecret: dlp-api-credentials
  secretKey: api-key
```

Secret içindeki anahtar rotate edildiğinde environment variable kullanan mevcut
pod'lar değeri otomatik yenilemez. Backend ve frontend deployment'ları yeniden
başlatılmalıdır.

Ham yükleme ve maskelenmemiş Parquet chunk dosyaları yalnızca görev çalışırken
geçici olarak PVC'de bulunur. Görev tamamlandığında veya başarısız olduğunda
hemen silinir ve PostgreSQL'deki ilgili path alanları temizlenir. PostgreSQL satır
içeriği tutmaz; yalnızca operasyonel job/chunk metadata'sı kalır. Başarılı bir
görev için PVC'de yalnızca final maskelenmiş çıktı tutulur. Çıktı otomatik olarak
silinmez; yetkili kullanıcı workspace yönetim ekranından çalışma alanını silene
kadar saklanır.

## Ön koşullar

- OpenShift 4.x veya Kubernetes 1.25+
- Helm 3
- Backend ve frontend imajlarının müşteri registry'sinde bulunması
- Chart içi PostgreSQL/Redis kullanılacaksa bu imajların da kapalı ağ
  registry'sine mirror edilmesi
- Private registry için pull Secret
- Backend ve her worker model süreci için en az 2 GiB, önerilen 4 GiB limit
- Birden fazla pod/node kullanılacaksa ortak job alanı için RWX storage
- Chart içi PostgreSQL/Redis kullanılacaksa RWO storage class
- Route kullanılacaksa OpenShift Route API; standart Kubernetes'te Ingress

### Minimum storage gereksinimleri

| Alan | Minimum | Başlangıç önerisi | Erişim modu | Açıklama |
|---|---:|---:|---|---|
| `jobStorage` | 10 GiB | 20 GiB | RWX | Ayda 20–30 bin satır için geçici dosyalar ve kalıcı maskelenmiş çıktılar |
| Chart içi PostgreSQL | 8 GiB | 20 GiB | RWO | Yalnızca job/chunk metadata ve checkpoint kayıtları |
| Chart içi Redis | 2 GiB | 5 GiB | RWO | Celery broker ve geçici task sonuçları |

Chart tarafından PVC oluşturuluyorsa boyutlar tam sayı ve `Gi` birimiyle
yazılmalıdır (`10Gi` gibi). Daha düşük değerler Helm doğrulamasında reddedilir.
`jobStorage.existingClaim` kullanıldığında kapasite hazır PVC tarafından
yönetildiği için chart minimum kontrolü uygulamaz. Maskelenmiş çıktılar otomatik
silinmediğinden gerçek `jobStorage` kapasitesi kullanıcı sayısı, dosya boyutu ve
saklama politikasına göre minimumun üzerine çıkarılmalıdır.

Ayda 20–30 bin satır beklenen mevcut kullanım için `20Gi` başlangıç kapasitesi
önerilir. Bu öneri ortalama maskelenmiş satırın yaklaşık 10 KiB veya altında
olduğu varsayımıyla bir yıllık çıktı için geniş güvenlik payı bırakır. Çok sayıda
uzun metin kolonu, dosya eki benzeri büyük hücreler veya bir yıldan uzun saklama
varsa kapasite şu yaklaşık formülle yeniden hesaplanmalıdır:

```text
aylık satır × ortalama çıktı satırı byte × saklama ayı × 1.3 güvenlik payı
```

PVC kullanımına alarm kurulması ve kapasitenin %70–80 seviyesinde genişletilmesi
önerilir. `jobStorage` storage class'ı volume expansion desteklemiyorsa başlangıç
kapasitesi daha yüksek seçilmelidir.

### Minimum CPU ve RAM gereksinimleri

Aşağıdaki değerler `backend=1`, `worker=1`, `worker.concurrency=1`, `frontend=1`,
`beat=1`, chart içi Redis ve chart içi PostgreSQL topolojisi içindir:

| Bileşen | CPU request | RAM request | CPU limit | RAM limit |
|---|---:|---:|---:|---:|
| Backend | 1 core | 2 GiB | 2 core | 4 GiB |
| Worker | 1 core | 2 GiB | 2 core | 4 GiB |
| Frontend | 100m | 128 MiB | 500m | 512 MiB |
| Beat | 50m | 128 MiB | 250m | 256 MiB |
| PostgreSQL | 250m | 512 MiB | 1 core | 1 GiB |
| Redis | 100m | 128 MiB | 500m | 512 MiB |
| **Toplam** | **2.5 core** | **yaklaşık 5 GiB** | **6.25 core** | **yaklaşık 10.25 GiB** |

OpenShift sistem podları, image açma işlemleri ve ani bellek kullanımı bu toplama
dahil değildir. Tek node CRC/PoC ortamı için uygulamaya ayrılabilir en az `8
vCPU / 16 GiB RAM`, rahat test için `12 vCPU / 24 GiB RAM` önerilir. Production
ortamında namespace quota en az tablodaki toplam request ve limitleri karşılamalı,
node'larda platform yüküne ek olarak yeterli allocatable kaynak bulunmalıdır.

Müşteri harici PostgreSQL kullandığında uygulama namespace ihtiyacından
PostgreSQL satırı çıkarılabilir. Her ek worker replica toplam ihtiyaca yaklaşık
`1 CPU / 2 GiB` request ve `2 CPU / 4 GiB` limit ekler. `worker.concurrency`
değerini yükseltmek aynı pod içinde yeni model süreçleri oluşturduğu için RAM
ihtiyacını benzer oranda artırır; bu nedenle `concurrency=1` bırakılıp replica
sayısının artırılması önerilir.

## Teslim dosyasını hazırlama

Hedef ortama uygun müşteri profilini seçip kopyalayın:

* **Standart CPU Kurulumu:**
  ```bash
  cp helm/dlp-masking-service/values-customer.cpu.yaml values-customer.yaml
  ```
* **NVIDIA GPU Destekli Kurulum:**
  ```bash
  cp helm/dlp-masking-service/values-customer.gpu.yaml values-customer.yaml
  ```

En az şu alanları müşteriye göre düzenleyin:

- `backend.image.repository/tag`
- `frontend.image.repository/tag`
- Dahili servis kullanılacaksa `postgresql.image.*` ve `redis.image.*`
- `global.imagePullSecrets`
- `jobStorage.storageClass` veya `jobStorage.existingClaim`
- PostgreSQL/Redis modu ve Secret adları
- `guardPipeline` ayarları (`vllmApiUrl`, `m2Mode` vb.)
- `route.frontend.host`
- CPU/RAM/GPU limitleri ve worker replica sayısı
- `fileProcessing.maxFileSizeBytes`

Gerçek parola içeren `values-customer.yaml` dosyasını Git'e eklemeyin.

## Registry erişimi

Private registry için namespace içinde pull Secret oluşturun:

```bash
oc create secret docker-registry customer-registry-pull-secret \
  --docker-server=registry.customer.example \
  --docker-username='<registry-user>' \
  --docker-password='<registry-password>' \
  -n dlp-masking-service
```

Values karşılığı:

```yaml
global:
  imagePullSecrets:
    - name: customer-registry-pull-secret
```

Repository tam registry adresi içermiyorsa uygulama imajları için
`global.imageRegistry` da kullanılabilir. PostgreSQL ve Redis imajları doğrudan
`postgresql.image.repository` ve `redis.image.repository` alanlarından okunur;
kapalı ağ kurulumunda tam müşteri registry adresini bu alanlara yazın:

```yaml
postgresql:
  image:
    repository: registry.customer.example/dlp/postgresql-16-c9s
    tag: latest

redis:
  image:
    repository: registry.customer.example/dlp/redis-7-c9s
    tag: latest
```

## AMD64 ve çevrimdışı image teslimi

OpenShift worker node'ları AMD64 ise teslim edilen bütün imajların platformu
`linux/amd64` olmalıdır. Apple Silicon üzerinde alınan varsayılan `arm64`
imajlar bu cluster'da çalışmaz. Bu kurulumda harici PostgreSQL kullanıldığında
teslim setinde üç imaj bulunur:

- `dlp-masking-service-backend:1.0.1`
- `dlp-masking-service-frontend:1.0.1`
- `dlp-masking-service-redis:1.0.1`

İlk teslim registry yerine tek bir sıkıştırılmış Docker arşivi olarak yapılabilir:

```bash
docker save \
  coone/dlp-masking-service-backend:1.0.1 \
  coone/dlp-masking-service-frontend:1.0.1 \
  coone/dlp-masking-service-redis:1.0.1 \
  | gzip > dlp-masking-images-1.0.1-linux-amd64.tar.gz

sha256sum dlp-masking-images-1.0.1-linux-amd64.tar.gz
```

Müşteri arşivi `podman load -i` veya `docker load -i` ile açar, imajları kendi
registry adresiyle yeniden tag'leyip push eder. OpenShift doğrudan teslim edilen
tar dosyasından image çekmez; Helm kurulumundan önce imajların cluster'ın
erişebildiği bir registry'de bulunması gerekir. Values içindeki repository
örneği şu biçimdedir:

```yaml
backend:
  image:
    repository: registry.customer.example/dlp/dlp-masking-service-backend
    tag: "1.0.1"
frontend:
  image:
    repository: registry.customer.example/dlp/dlp-masking-service-frontend
    tag: "1.0.1"
redis:
  image:
    repository: registry.customer.example/dlp/dlp-masking-service-redis
    tag: "1.0.1"
```

GHCR kullanılmaya başlandığında yalnızca repository alanları değişir:
`ghcr.io/<organization>/dlp-masking-service-backend` ve
`ghcr.io/<organization>/dlp-masking-service-frontend`. Tag aynı sürüm olarak
kalabilir.

## Secret yönetimi

### Önerilen: müşteri tarafından oluşturulan Secret

PostgreSQL Secret'ı üç anahtar içermelidir:

```bash
oc create secret generic dlp-postgresql-credentials \
  --from-literal=postgres-database='dlp' \
  --from-literal=postgres-username='dlp' \
  --from-literal=postgres-password='<strong-password>' \
  -n dlp-masking-service

oc create secret generic dlp-redis-credentials \
  --from-literal=redis-password='<strong-password>' \
  -n dlp-masking-service
```

Secret'ları Helm kurulumundan önce ve aynı namespace'te oluşturun:

```yaml
postgresql:
  auth:
    existingSecret: dlp-postgresql-credentials
    databaseKey: postgres-database
    usernameKey: postgres-username
    passwordKey: postgres-password

redis:
  auth:
    existingSecret: dlp-redis-credentials
    passwordKey: redis-password
```

Bu yöntem External Secrets Operator, Sealed Secrets veya kurumun secret
yönetim ürünüyle uyumludur; chart ilgili Secret'ı sahiplenmez veya silmez.

### Alternatif: Helm tarafından yönetilen Secret

`existingSecret: ""` bırakılır. `password` verilirse chart onu kullanır; boş
bırakılırsa ilk kurulumda 32 karakterli parola üretir. Upgrade sırasında mevcut
Secret'taki parola korunur.

```yaml
postgresql:
  auth:
    database: dlp
    username: dlp
    password: ""
    existingSecret: ""

redis:
  auth:
    password: ""
    existingSecret: ""
```

Üretilen parolayı görmek için:

```bash
oc get secret dlp-masking-service-postgresql \
  -n dlp-masking-service \
  -o jsonpath='{.data.postgres-password}' | base64 -d

oc get secret dlp-masking-service-redis \
  -n dlp-masking-service \
  -o jsonpath='{.data.redis-password}' | base64 -d
```

Parolayı `--set` ile vermek shell history ve Helm release metadata'sında iz
bırakabileceğinden production ortamında önerilmez.

## PostgreSQL ve Redis seçenekleri

### Chart içi servisler

```yaml
postgresql:
  enabled: true
  host: ""
  port: 5432
  image:
    repository: registry.customer.example/dlp/postgresql-16-c9s
    tag: latest
  persistence:
    storageClass: customer-rwo-storage
    size: 20Gi

redis:
  enabled: true
  host: ""
  port: 6379
  image:
    repository: registry.customer.example/dlp/redis-7-c9s
    tag: latest
  persistence:
    storageClass: customer-rwo-storage
    size: 5Gi
```

### Kurumsal/harici servisler

`enabled=false` olduğunda `host` zorunludur. Credential Secret yapısı değişmez.

```yaml
postgresql:
  enabled: false
  host: postgresql.database.svc.cluster.local
  port: 5432
  sslMode: require
  auth:
    existingSecret: dlp-postgresql-credentials

redis:
  enabled: false
  host: redis.cache.svc.cluster.local
  port: 6379
  auth:
    existingSecret: dlp-redis-credentials
```

Desteklenen PostgreSQL `sslMode` değerleri: `disable`, `allow`, `prefer`,
`require`, `verify-ca`, `verify-full`. `verify-ca` ve `verify-full` kullanılıyorsa
kurumsal CA'nın container trust store'una eklenmesi platform ekibinin
sorumluluğundadır; gerekli env/mount genişletmeleri müşteri overlay'iyle
verilebilir.

## Ortak job storage

Backend, worker ve beat aynı PVC'yi bağlar. Birden fazla worker replica veya
farklı node kullanılacaksa storage class `ReadWriteMany` desteklemelidir:

```yaml
jobStorage:
  storageClass: customer-rwx-storage
  accessModes: [ReadWriteMany]
  size: 20Gi
```

Bu değer aylık 20–30 bin satırlık başlangıç hacmi içindir; gerçek çıktı boyutu
ve saklama süresine göre izlenip büyütülmelidir.

Platform ekibi PVC'yi önceden oluşturduysa chart'ın PVC üretmesini kapatın:

```yaml
jobStorage:
  existingClaim: dlp-shared-jobs
```

Ham ve ara dosyalar görev bittiğinde veya kullanıcı görevi durdurduğunda hemen
temizlenir. Aktif görev kartındaki **Görevi durdur** işlemi Celery görevlerini
iptal eder ve job durumunu `cancelled` yapar. Terminal durumdaki görevler
(`completed`, `failed`, `cancelled`, `expired`) **Görevi sil** ile metadata ve
dosyalarıyla birlikte tek tek kaldırılabilir. Final maskelenmiş çıktı, job veya
workspace manuel olarak silinene kadar tutulur. Workspace silme işlemi kalan tüm
job metadata'sını ve maskelenmiş çıktıları kalıcı olarak kaldırır. PVC rastgele
OpenShift UID'si tarafından yazılabilir olmalıdır.

## Dosya limiti ve chunk ayarları

Upload limiti byte cinsindendir:

```yaml
fileProcessing:
  maxFileSizeBytes: 104857600 # 100 MiB
```

Reverse proxy, Route veya ingress controller daha düşük bir body-size limitine
sahipse platformdaki limit de ayrıca yükseltilmelidir.

Worker ayarları:

```yaml
worker:
  chunkRows: 250
  chunkTargetCells: 100
  chunkDispatchBatch: 8
  maxChunkAttempts: 3
  chunkRetryBaseSeconds: 5
  chunkSoftTimeLimit: 1800
  chunkHardTimeLimit: 1860
```

- `chunkRows`: chunk başına satır üst sınırı.
- `chunkTargetCells`: çok kolonlu dosyalarda yaklaşık seçili hücre hedefi.
- `chunkDispatchBatch`: tek job'ın bir dalgada broker'a vereceği chunk sayısı.
- `maxChunkAttempts`: ilk çalışma dahil toplam deneme sayısı.
- Retry gecikmesi exponential backoff uygular.
- Hard timeout soft timeout'tan büyük olmalıdır.

## Paralellik ve kaynak planlama

Efektif paralellik `worker.replicaCount × worker.concurrency` değeridir. Her
prefork process modeli ayrı yükler. Yerel ölçümde tek model worker'ı yaklaşık
2.2 GiB kullandığı için önerilen başlangıç profili:

```yaml
worker:
  replicaCount: 1
  concurrency: 1
  resources:
    requests:
      cpu: "1"
      memory: 2Gi
    limits:
      cpu: "2"
      memory: 4Gi
```

Daha fazla paralellik için aynı podda concurrency yükseltmek yerine
`replicaCount` artırılması önerilir. Her replica ortak RWX PVC'ye erişebilmelidir.
GPU kullanılıyorsa replica/concurrency ayarı GPU belleğine göre ayrıca test
edilmelidir.

CPU-only müşteri kurulumu için `values-customer.cpu.yaml`, worker'ı
`concurrency=1`, `2 CPU / 6 GiB` request ve `8 CPU / 12 GiB` limit ile
çalıştırır. Aynı dosyada OpenMP, MKL, OpenBLAS ve NumExpr thread sayıları `8`
olarak sabitlenmiştir. Bu ayar PyTorch'un cgroup CPU kotasından daha fazla node
CPU'su görmesi durumunda aşırı thread açmasını ve context-switch yükünü önler.
Thread değerleri worker CPU limitinden yüksek ayarlanmamalıdır.

## Route ve erişim

```yaml
route:
  frontend:
    enabled: true
    host: dlp-masking.apps.customer.example
    tls:
      enabled: true
      termination: edge
      insecureEdgeTerminationPolicy: Redirect
  backend:
    enabled: false
```

Backend Route yalnızca doğrudan API erişimi gerekiyorsa açılmalıdır.
`workspaceMonitor.enabled=true` workspace kimliklerini listeler; yalnızca
kimlik doğrulamalı iç yönetim ekranlarında kullanılmalıdır. Yönetim ekranındaki
silme ikonu seçilen workspace'in ID'sinin birebir yazılmasını ister; aktif işi
olan workspace silinemez. Onaylanan işlem job/chunk metadata'sını ve bütün final
maskelenmiş çıktıları kalıcı olarak kaldırır.

Standart Kubernetes ortamında `route.*.enabled=false` ve `ingress.enabled=true`
kullanılabilir.

## Kurulum öncesi doğrulama

Chart, `values.schema.json` ile port, concurrency, dosya limiti ve external host
gibi kritik alanları doğrular.

```bash
helm lint helm/dlp-masking-service -f values-customer.yaml

helm template dlp-masking-service helm/dlp-masking-service \
  --namespace dlp-masking-service \
  -f values-customer.yaml > rendered.yaml

oc apply --dry-run=server -f rendered.yaml
```

`rendered.yaml` Secret verisi içerebilir; doğrulama sonrasında güvenli biçimde
silin ve Git'e eklemeyin.

## Kurulum

```bash
oc new-project dlp-masking-service

helm upgrade --install dlp-masking-service helm/dlp-masking-service \
  --namespace dlp-masking-service \
  --create-namespace \
  -f values-customer.yaml \
  --atomic \
  --timeout 15m
```

Backend ilk açılışta modeli RAM'e yüklediği için startup probe 10 dakikaya kadar
bekleyecek şekilde ayarlanmıştır.

## Doğrulama

```bash
oc get pods,svc,pvc,route -n dlp-masking-service

oc rollout status deployment/dlp-masking-service-backend \
  -n dlp-masking-service --timeout=10m
oc rollout status deployment/dlp-masking-service-worker \
  -n dlp-masking-service --timeout=10m
oc rollout status deployment/dlp-masking-service-frontend \
  -n dlp-masking-service --timeout=5m

oc logs deployment/dlp-masking-service-worker \
  -n dlp-masking-service --tail=100
```

Backend sağlık kontrolü:

```bash
oc port-forward service/dlp-masking-service-backend 8000:8000 \
  -n dlp-masking-service
curl http://localhost:8000/health
```

Beklenen cevap:

```json
{"status":"ok"}
```

PostgreSQL checkpoint kontrolü:

```bash
oc exec statefulset/dlp-masking-service-postgresql \
  -n dlp-masking-service -- \
  psql -U dlp -d dlp -c \
  "select status,count(*) from masking_jobs group by status;"
```

Harici PostgreSQL kullanılıyorsa aynı sorguyu kurumun standart DB erişim
yöntemiyle çalıştırın.

## Upgrade ve rollback

Upgrade öncesinde PostgreSQL yedeği alın ve job PVC kapasitesini kontrol edin:

```bash
helm upgrade dlp-masking-service helm/dlp-masking-service \
  --namespace dlp-masking-service \
  -f values-customer.yaml \
  --atomic \
  --timeout 15m

helm history dlp-masking-service -n dlp-masking-service
helm rollback dlp-masking-service <revision> -n dlp-masking-service
```

Worker normal kapanışta açık chunk lease'lerini serbest bırakır. Yeni worker
hazır olduğunda recovery task'ı otomatik tetiklenir; tamamlanan chunk'lar yeniden
işlenmez.

## Önemli parametreler

| Parametre | Varsayılan | Açıklama |
|---|---:|---|
| `fileProcessing.maxFileSizeBytes` | `26214400` | Upload sınırı, byte |
| `worker.replicaCount` | `1` | Worker pod sayısı |
| `worker.concurrency` | `1` | Pod başına model process sayısı |
| `worker.chunkRows` | `250` | Chunk satır üst sınırı |
| `worker.chunkTargetCells` | `100` | Chunk hücre hedefi |
| `worker.chunkDispatchBatch` | `8` | Job başına dispatch dalgası |
| `worker.maxChunkAttempts` | `3` | Toplam chunk denemesi |
| `jobStorage.existingClaim` | `""` | Mevcut ortak PVC |
| `postgresql.enabled` | `true` | Chart içi PostgreSQL |
| `postgresql.host/port` | internal / `5432` | Harici PostgreSQL adresi |
| `postgresql.sslMode` | `""` | Opsiyonel libpq SSL modu |
| `postgresql.image.repository/tag` | SCL PostgreSQL 16 | Dahili DB imajı |
| `postgresql.auth.existingSecret` | `""` | Mevcut DB credential Secret |
| `redis.enabled` | `true` | Chart içi Redis |
| `redis.host/port` | internal / `6379` | Harici Redis adresi |
| `redis.image.repository/tag` | SCL Redis 7 | Dahili broker imajı |
| `redis.auth.existingSecret` | `""` | Mevcut Redis Secret |
| `workspaceMonitor.enabled` | `false` | Workspace yönetim görünümü |
| `route.frontend.enabled` | `true` | OpenShift frontend Route |
| `route.backend.enabled` | `false` | Backend API Route |
| `networkPolicy.enabled` | `false` | Chart NetworkPolicy kaynakları |

## Güvenlik notları

- Podlar sabit UID istemez ve OpenShift restricted SCC ile çalışır.
- Privilege escalation kapalıdır; Linux capability'leri düşürülür.
- ServiceAccount token otomatik mount edilmez.
- Backend Route ve workspace monitor varsayılan olarak kapalıdır.
- Production credential'ları için `existingSecret` kullanın.
- Müşteri tesliminde tüm container imajlarını onaylı ve değişmez bir tag ile
  sabitleyin; örnekteki `latest` değerini production'da kullanmayın.
- NetworkPolicy'yi açmadan önce DNS, ingress namespace ve harici DB/Redis
  erişimini müşteri CNI politikalarıyla doğrulayın.
- PostgreSQL job/chunk metadata'sını ve job PVC'sini kurumun yedekleme
  politikasına dahil edin.
