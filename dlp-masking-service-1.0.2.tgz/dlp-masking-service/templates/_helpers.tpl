{{- define "dlp-masking-service.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{- define "dlp-masking-service.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end }}

{{- define "dlp-masking-service.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{- define "dlp-masking-service.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dlp-masking-service.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "dlp-masking-service.labels" -}}
helm.sh/chart: {{ include "dlp-masking-service.chart" . }}
{{ include "dlp-masking-service.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "dlp-masking-service.backend.selectorLabels" -}}
{{ include "dlp-masking-service.selectorLabels" . }}
app.kubernetes.io/component: backend
{{- end }}

{{- define "dlp-masking-service.backend.labels" -}}
{{ include "dlp-masking-service.labels" . }}
app.kubernetes.io/component: backend
{{- end }}

{{- define "dlp-masking-service.frontend.selectorLabels" -}}
{{ include "dlp-masking-service.selectorLabels" . }}
app.kubernetes.io/component: frontend
{{- end }}

{{- define "dlp-masking-service.frontend.labels" -}}
{{ include "dlp-masking-service.labels" . }}
app.kubernetes.io/component: frontend
{{- end }}

{{- define "dlp-masking-service.worker.selectorLabels" -}}
{{ include "dlp-masking-service.selectorLabels" . }}
app.kubernetes.io/component: worker
{{- end }}

{{- define "dlp-masking-service.worker.labels" -}}
{{ include "dlp-masking-service.labels" . }}
app.kubernetes.io/component: worker
{{- end }}

{{- define "dlp-masking-service.beat.selectorLabels" -}}
{{ include "dlp-masking-service.selectorLabels" . }}
app.kubernetes.io/component: beat
{{- end }}

{{- define "dlp-masking-service.postgresql.selectorLabels" -}}
{{ include "dlp-masking-service.selectorLabels" . }}
app.kubernetes.io/component: postgresql
{{- end }}

{{- define "dlp-masking-service.redis.selectorLabels" -}}
{{ include "dlp-masking-service.selectorLabels" . }}
app.kubernetes.io/component: redis
{{- end }}

{{- define "dlp-masking-service.vllm.selectorLabels" -}}
{{ include "dlp-masking-service.selectorLabels" . }}
app.kubernetes.io/component: vllm
{{- end }}

{{- define "dlp-masking-service.vllm.labels" -}}
{{ include "dlp-masking-service.labels" . }}
app.kubernetes.io/component: vllm
{{- end }}

{{- define "dlp-masking-service.vllm.apiUrl" -}}
{{- if .Values.guardPipeline.vllmApiUrl -}}
{{- .Values.guardPipeline.vllmApiUrl -}}
{{- else if .Values.vllm.enabled -}}
{{- printf "http://%s-vllm.%s.svc.cluster.local:%d/v1/chat/completions" (include "dlp-masking-service.fullname" .) (.Release.Namespace | default "default") (int .Values.vllm.service.port) -}}
{{- end -}}
{{- end }}

{{- define "dlp-masking-service.postgresql.secretName" -}}
{{- default (printf "%s-postgresql" (include "dlp-masking-service.fullname" .)) .Values.postgresql.auth.existingSecret -}}
{{- end }}

{{- define "dlp-masking-service.redis.secretName" -}}
{{- default (printf "%s-redis" (include "dlp-masking-service.fullname" .)) .Values.redis.auth.existingSecret -}}
{{- end }}

{{- define "dlp-masking-service.postgresql.host" -}}
{{- if .Values.postgresql.host -}}
{{- .Values.postgresql.host -}}
{{- else if .Values.postgresql.enabled -}}
{{- printf "%s-postgresql" (include "dlp-masking-service.fullname" .) -}}
{{- else -}}
{{- required "postgresql.host is required when postgresql.enabled=false" .Values.postgresql.host -}}
{{- end -}}
{{- end }}

{{- define "dlp-masking-service.redis.host" -}}
{{- if .Values.redis.host -}}
{{- .Values.redis.host -}}
{{- else if .Values.redis.enabled -}}
{{- printf "%s-redis" (include "dlp-masking-service.fullname" .) -}}
{{- else -}}
{{- required "redis.host is required when redis.enabled=false" .Values.redis.host -}}
{{- end -}}
{{- end }}

{{- define "dlp-masking-service.jobStorageClaimName" -}}
{{- default (printf "%s-jobs" (include "dlp-masking-service.fullname" .)) .Values.jobStorage.existingClaim -}}
{{- end }}

{{- define "dlp-masking-service.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "dlp-masking-service.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end }}

{{- define "dlp-masking-service.image" -}}
{{- $root := .root -}}
{{- $image := .image -}}
{{- $repository := required "image.repository is required" $image.repository -}}
{{- $tag := default $root.Chart.AppVersion $image.tag -}}
{{- $registry := trimSuffix "/" $root.Values.global.imageRegistry -}}
{{- $firstPart := first (splitList "/" $repository) -}}
{{- $repositoryHasRegistry := or (contains "." $firstPart) (contains ":" $firstPart) (eq $firstPart "localhost") -}}
{{- if and $registry (not $repositoryHasRegistry) -}}
{{- printf "%s/%s:%s" $registry $repository $tag -}}
{{- else -}}
{{- printf "%s:%s" $repository $tag -}}
{{- end -}}
{{- end }}
